# Agroguard v2.4 — Mapa de Chile

Se conserva el motor de Agroguard v2.3 y la comparación de rotaciones. Se reemplaza el selector de cuatro localidades por un mapa esquemático de Chile, seis zonas y 17 ciudades. El usuario escoge zona y ciudad; las coordenadas aproximadas WGS84 se envían en el mismo cuerpo JSON que antes (`lat`, `lon`) y NASA POWER consulta los datos históricos de ese punto. **No son datos promedio de una zona ni datos de suelo**. La consulta depende de conexión a internet y del servicio NASA POWER.

El mapa es esquemático: no es cartografía administrativa oficial. Los botones y el selector de zonas son alternativas accesibles.

## Inicio
Backend: `cd backend; py -3.12 -m venv .venv; .\.venv\Scripts\python.exe -m pip install -r requirements.txt; .\.venv\Scripts\python.exe -m uvicorn main:app --reload --port 8000`
Frontend: `cd frontend; npm.cmd install; npm.cmd run dev`

Abrir http://localhost:5173.

## Versión v2.5 — identidad azul
- Interfaz rediseñada con tonos azules, celestes y cian, tarjetas y controles refinados.
- Mapa de Chile recoloreado con la nueva identidad.
- Sección final «¿Por qué hacemos Agroguard?» con propósito y tres pilares.
- Backend y lógica de puntuación conservados sin cambios respecto a v2.4.

## v2.6
- Vuelve la paleta de verdes, verde bosque y menta.
- Se conserva el apartado final del propósito del proyecto.
- Sin cambios al motor de comparación ni a NASA POWER.

## v2.7 — presentación centrada en agricultores
- Identidad Agroguard rediseñada: logotipo vectorial integrado, cabecera profesional, portada y verde bosque.
- Resultado destacado: mejor alternativa evaluada (excluye la práctica actual cuando se identifica).
- Otras rotaciones en tarjetas simples, práctica actual separada.
- Un gráfico horizontal comparativo usando exactamente las puntuaciones calculadas por el backend.
- Análisis técnico, notas, acciones y limitaciones en sección expandible «Ver análisis detallado».
- No se cambió la lógica del backend, los puntajes son experimentales.
