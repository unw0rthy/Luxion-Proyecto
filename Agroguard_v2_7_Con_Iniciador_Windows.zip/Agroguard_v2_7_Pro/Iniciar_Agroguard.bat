@echo off
setlocal
cd /d "%~dp0"
title Agroguard - Iniciador

echo ==============================================
echo          AGROGUARD - INICIADOR
 echo ==============================================
if not exist "backend\main.py" (
 echo ERROR: No se encuentra backend\main.py
 pause
 exit /b 1
)
if not exist "frontend\package.json" (
 echo ERROR: No se encuentra frontend\package.json
 pause
 exit /b 1
)

if not exist "backend\.venv\Scripts\python.exe" (
 echo [1/3] Preparando Python por primera vez...
 py -3.12 -m venv "backend\.venv"
 if errorlevel 1 (
  echo ERROR: Instala Python 3.12 o revisa el comando py.
  pause
  exit /b 1
 )
)
"backend\.venv\Scripts\python.exe" -c "import uvicorn, fastapi" >nul 2>&1
if errorlevel 1 (
 echo [1/3] Instalando dependencias Python...
 "backend\.venv\Scripts\python.exe" -m pip install -r "backend\requirements.txt"
 if errorlevel 1 (
  echo ERROR: Fallo la instalacion de Python.
  pause
  exit /b 1
 )
)
if not exist "frontend\node_modules\vite\bin\vite.js" (
 echo [2/3] Instalando dependencias web por primera vez...
 pushd frontend
 call npm.cmd install
 if errorlevel 1 (
  popd
  echo ERROR: Instala Node.js o revisa npm.
  pause
  exit /b 1
 )
 popd
)

echo [3/3] Iniciando servicios...
start "Agroguard - API" cmd /k "cd /d ""%~dp0backend"" && "".venv\Scripts\python.exe"" -m uvicorn main:app --host 127.0.0.1 --port 8000"
start "Agroguard - Interfaz" cmd /k "cd /d ""%~dp0frontend"" && npm.cmd run dev"
echo.
echo Abriendo Agroguard en el navegador...
timeout /t 6 /nobreak >nul
start "" "http://127.0.0.1:5173/"
echo.
echo Puedes cerrar esta ventana. Mantén abiertas las ventanas de API e Interfaz.
echo Para detener Agroguard, presiona Ctrl+C en cada una.
timeout /t 8 /nobreak >nul
endlocal
